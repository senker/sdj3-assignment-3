package via.sdj3.slaughterhousegrpcspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlaughterhouseGrpcSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlaughterhouseGrpcSpringbootApplication.class, args);
	}

}
