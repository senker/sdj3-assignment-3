package via.sdj3.slaughterhousegrpcspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlaughterhouseGrpcSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
